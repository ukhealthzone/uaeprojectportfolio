import { Card } from "@/components/ui/card"
import { Database, Brain, Users, CheckCircle2, AlertTriangle, GitBranch } from "lucide-react"

export function LabelingWorkflowDiagram() {
  return (
    <Card className="p-8 bg-white">
      <div className="space-y-8">
        {/* Input */}
        <div className="flex justify-center">
          <div className="p-4 bg-slate-100 rounded-lg border-2 border-slate-300">
            <div className="flex items-center gap-3">
              <Database className="w-6 h-6 text-slate-600" />
              <div>
                <h4 className="font-semibold text-slate-900">Raw Data</h4>
                <p className="text-sm text-slate-600">18.7M property records</p>
              </div>
            </div>
          </div>
        </div>

        {/* Arrow Down */}
        <div className="flex justify-center">
          <div className="w-0.5 h-12 bg-slate-300 relative">
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0 border-t-8 border-t-slate-300 border-l-4 border-l-transparent border-r-4 border-r-transparent"></div>
          </div>
        </div>

        {/* Three Paths */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Automated Labeling */}
          <div className="space-y-4">
            <div className="p-4 bg-green-50 rounded-lg border-2 border-green-200">
              <div className="flex items-center gap-2 mb-3">
                <Brain className="w-6 h-6 text-green-600" />
                <h4 className="font-semibold text-slate-900">Automated</h4>
              </div>
              <div className="text-2xl font-bold text-green-600 mb-1">70%</div>
              <p className="text-sm text-slate-600 mb-3">13.1M records</p>
              <div className="space-y-2 text-xs text-slate-700">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                  <span>Historical transaction prices</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                  <span>CV feature extraction</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                  <span>Rule-based validation</span>
                </div>
              </div>
            </div>
          </div>

          {/* Semi-Automated */}
          <div className="space-y-4">
            <div className="p-4 bg-amber-50 rounded-lg border-2 border-amber-200">
              <div className="flex items-center gap-2 mb-3">
                <GitBranch className="w-6 h-6 text-amber-600" />
                <h4 className="font-semibold text-slate-900">Semi-Auto</h4>
              </div>
              <div className="text-2xl font-bold text-amber-600 mb-1">20%</div>
              <p className="text-sm text-slate-600 mb-3">3.7M records</p>
              <div className="space-y-2 text-xs text-slate-700">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                  <span>Active learning selection</span>
                </div>
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                  <span>Expert validation</span>
                </div>
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                  <span>Quality scoring</span>
                </div>
              </div>
            </div>
          </div>

          {/* Manual */}
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
              <div className="flex items-center gap-2 mb-3">
                <Users className="w-6 h-6 text-blue-600" />
                <h4 className="font-semibold text-slate-900">Manual</h4>
              </div>
              <div className="text-2xl font-bold text-blue-600 mb-1">10%</div>
              <p className="text-sm text-slate-600 mb-3">1.9M records</p>
              <div className="space-y-2 text-xs text-slate-700">
                <div className="flex items-start gap-2">
                  <Users className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                  <span>Luxury properties</span>
                </div>
                <div className="flex items-start gap-2">
                  <Users className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                  <span>New developments</span>
                </div>
                <div className="flex items-start gap-2">
                  <Users className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                  <span>Expert assessment</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Arrow Down */}
        <div className="flex justify-center">
          <div className="w-0.5 h-12 bg-slate-300 relative">
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0 border-t-8 border-t-slate-300 border-l-4 border-l-transparent border-r-4 border-r-transparent"></div>
          </div>
        </div>

        {/* Quality Control */}
        <div>
          <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">Quality Control</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
              <h4 className="font-semibold text-slate-900 mb-2 text-sm">Triple Annotation</h4>
              <p className="text-xs text-slate-600">10% random sample reviewed by 3 annotators</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
              <h4 className="font-semibold text-slate-900 mb-2 text-sm">Consistency Checks</h4>
              <p className="text-xs text-slate-600">Automated validation across related properties</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
              <h4 className="font-semibold text-slate-900 mb-2 text-sm">Expert Audits</h4>
              <p className="text-xs text-slate-600">Quarterly review by domain experts</p>
            </div>
          </div>
        </div>

        {/* Arrow Down */}
        <div className="flex justify-center">
          <div className="w-0.5 h-12 bg-slate-300 relative">
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0 border-t-8 border-t-slate-300 border-l-4 border-l-transparent border-r-4 border-r-transparent"></div>
          </div>
        </div>

        {/* Output */}
        <div className="flex justify-center">
          <div className="p-6 bg-teal-50 rounded-lg border-2 border-teal-200 max-w-md">
            <div className="flex items-center gap-3 mb-3">
              <CheckCircle2 className="w-8 h-8 text-teal-600" />
              <div>
                <h4 className="font-semibold text-slate-900">Labeled Dataset</h4>
                <p className="text-sm text-slate-600">18.7M high-quality records</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 text-center text-sm">
              <div>
                <div className="font-bold text-teal-600">0.92</div>
                <div className="text-xs text-slate-600">Inter-annotator Agreement</div>
              </div>
              <div>
                <div className="font-bold text-teal-600">98.1%</div>
                <div className="text-xs text-slate-600">Label Quality Score</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  )
}
