import { Card } from "@/components/ui/card"
import { Brain, TrendingUp, Zap, Target, CheckCircle2, XCircle } from "lucide-react"

export function HyperparameterTuningDiagram() {
  return (
    <Card className="p-8 bg-white">
      <div className="space-y-8">
        {/* Initialization */}
        <div>
          <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">1. Initialize Search Space</h3>
          <div className="p-6 bg-slate-50 rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold text-slate-900 mb-2 text-sm">Search Configuration</h4>
                <ul className="text-xs text-slate-600 space-y-1">
                  <li>
                    • <strong>Framework:</strong> Optuna (Bayesian Optimization)
                  </li>
                  <li>
                    • <strong>Search Space:</strong> 45 hyperparameters
                  </li>
                  <li>
                    • <strong>Trials:</strong> 500 iterations
                  </li>
                  <li>
                    • <strong>Pruning:</strong> Median-based early stopping
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-slate-900 mb-2 text-sm">Resource Allocation</h4>
                <ul className="text-xs text-slate-600 space-y-1">
                  <li>
                    • <strong>GPUs:</strong> 8x NVIDIA A100
                  </li>
                  <li>
                    • <strong>Parallel Trials:</strong> 8 simultaneous
                  </li>
                  <li>
                    • <strong>Budget:</strong> 200 GPU hours
                  </li>
                  <li>
                    • <strong>Duration:</strong> 5-7 days
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Arrow Down */}
        <div className="flex justify-center">
          <div className="w-0.5 h-12 bg-slate-300 relative">
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0 border-t-8 border-t-slate-300 border-l-4 border-l-transparent border-r-4 border-r-transparent"></div>
          </div>
        </div>

        {/* Optimization Loop */}
        <div>
          <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">2. Bayesian Optimization Loop</h3>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            <div className="p-4 bg-blue-50 rounded-lg text-center border-2 border-blue-200">
              <div className="w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-2 font-bold">
                1
              </div>
              <h4 className="font-semibold text-slate-900 text-xs mb-1">Sample Params</h4>
              <p className="text-xs text-slate-600">TPE sampler</p>
            </div>
            <div className="p-4 bg-purple-50 rounded-lg text-center border-2 border-purple-200">
              <div className="w-10 h-10 bg-purple-600 text-white rounded-full flex items-center justify-center mx-auto mb-2 font-bold">
                2
              </div>
              <h4 className="font-semibold text-slate-900 text-xs mb-1">Train Model</h4>
              <p className="text-xs text-slate-600">Cross-validation</p>
            </div>
            <div className="p-4 bg-amber-50 rounded-lg text-center border-2 border-amber-200">
              <div className="w-10 h-10 bg-amber-600 text-white rounded-full flex items-center justify-center mx-auto mb-2 font-bold">
                3
              </div>
              <h4 className="font-semibold text-slate-900 text-xs mb-1">Evaluate</h4>
              <p className="text-xs text-slate-600">Validation MAPE</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg text-center border-2 border-green-200">
              <div className="w-10 h-10 bg-green-600 text-white rounded-full flex items-center justify-center mx-auto mb-2 font-bold">
                4
              </div>
              <h4 className="font-semibold text-slate-900 text-xs mb-1">Update Prior</h4>
              <p className="text-xs text-slate-600">Gaussian Process</p>
            </div>
            <div className="p-4 bg-teal-50 rounded-lg text-center border-2 border-teal-200">
              <div className="w-10 h-10 bg-teal-600 text-white rounded-full flex items-center justify-center mx-auto mb-2 font-bold">
                5
              </div>
              <h4 className="font-semibold text-slate-900 text-xs mb-1">Prune?</h4>
              <p className="text-xs text-slate-600">Early stop check</p>
            </div>
          </div>
          <div className="mt-4 text-center text-sm text-slate-600">
            Loop repeats for 500 trials or until convergence
          </div>
        </div>

        {/* Arrow Down */}
        <div className="flex justify-center">
          <div className="w-0.5 h-12 bg-slate-300 relative">
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0 border-t-8 border-t-slate-300 border-l-4 border-l-transparent border-r-4 border-r-transparent"></div>
          </div>
        </div>

        {/* Trial Examples */}
        <div>
          <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">3. Trial Progress Visualization</h3>
          <div className="space-y-2">
            {[
              { trial: 1, mape: 4.8, status: "complete", color: "red" },
              { trial: 2, mape: 4.2, status: "complete", color: "orange" },
              { trial: 5, mape: 3.9, status: "complete", color: "amber" },
              { trial: 12, mape: 3.6, status: "complete", color: "yellow" },
              { trial: 34, mape: 3.4, status: "complete", color: "lime" },
              { trial: 89, mape: 3.3, status: "complete", color: "green" },
              { trial: 156, mape: 3.2, status: "complete", color: "teal" },
              { trial: 287, mape: 3.2, status: "best", color: "teal" },
            ].map((trial) => (
              <div key={trial.trial} className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
                <div className="w-20 text-sm font-medium text-slate-900">Trial {trial.trial}</div>
                <div className="flex-1">
                  <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className={`h-full bg-${trial.color}-500`}
                      style={{ width: `${Math.max(10, 100 - (trial.mape - 3.2) * 60)}%` }}
                    ></div>
                  </div>
                </div>
                <div className="w-20 text-sm font-semibold text-slate-900">{trial.mape}% MAPE</div>
                {trial.status === "best" ? (
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                ) : trial.status === "pruned" ? (
                  <XCircle className="w-5 h-5 text-red-600" />
                ) : (
                  <div className="w-5 h-5"></div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Arrow Down */}
        <div className="flex justify-center">
          <div className="w-0.5 h-12 bg-slate-300 relative">
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0 border-t-8 border-t-slate-300 border-l-4 border-l-transparent border-r-4 border-r-transparent"></div>
          </div>
        </div>

        {/* Best Parameters */}
        <div>
          <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">4. Optimal Configuration</h3>
          <div className="p-6 bg-gradient-to-r from-teal-50 to-teal-100 rounded-lg border-2 border-teal-300">
            <div className="flex items-center gap-3 mb-4">
              <Target className="w-8 h-8 text-teal-600" />
              <div>
                <h4 className="font-semibold text-slate-900">Best Hyperparameters (Trial 287)</h4>
                <p className="text-sm text-slate-600">Validation MAPE: 3.2% | Test MAPE: 3.19%</p>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
              <div className="p-3 bg-white rounded">
                <div className="text-xs text-slate-600">max_depth</div>
                <div className="font-bold text-teal-600">8</div>
              </div>
              <div className="p-3 bg-white rounded">
                <div className="text-xs text-slate-600">learning_rate</div>
                <div className="font-bold text-teal-600">0.045</div>
              </div>
              <div className="p-3 bg-white rounded">
                <div className="text-xs text-slate-600">n_estimators</div>
                <div className="font-bold text-teal-600">850</div>
              </div>
              <div className="p-3 bg-white rounded">
                <div className="text-xs text-slate-600">subsample</div>
                <div className="font-bold text-teal-600">0.82</div>
              </div>
              <div className="p-3 bg-white rounded">
                <div className="text-xs text-slate-600">colsample</div>
                <div className="font-bold text-teal-600">0.75</div>
              </div>
              <div className="p-3 bg-white rounded">
                <div className="text-xs text-slate-600">min_child_wt</div>
                <div className="font-bold text-teal-600">4</div>
              </div>
              <div className="p-3 bg-white rounded">
                <div className="text-xs text-slate-600">gamma</div>
                <div className="font-bold text-teal-600">0.3</div>
              </div>
              <div className="p-3 bg-white rounded">
                <div className="text-xs text-slate-600">reg_alpha</div>
                <div className="font-bold text-teal-600">0.001</div>
              </div>
            </div>
          </div>
        </div>

        {/* Performance Gains */}
        <div className="pt-6 border-t border-slate-200">
          <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">Performance Improvements</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-4 bg-teal-50 rounded-lg text-center">
              <TrendingUp className="w-8 h-8 text-teal-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-teal-600 mb-1">-18.5%</div>
              <div className="text-sm text-slate-700 font-medium">MAPE Reduction</div>
              <div className="text-xs text-slate-600 mt-1">From 3.9% to 3.2%</div>
            </div>
            <div className="p-4 bg-teal-50 rounded-lg text-center">
              <Brain className="w-8 h-8 text-teal-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-teal-600 mb-1">+5.8%</div>
              <div className="text-sm text-slate-700 font-medium">R² Score Increase</div>
              <div className="text-xs text-slate-600 mt-1">From 0.89 to 0.94</div>
            </div>
            <div className="p-4 bg-teal-50 rounded-lg text-center">
              <Zap className="w-8 h-8 text-teal-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-teal-600 mb-1">-42ms</div>
              <div className="text-sm text-slate-700 font-medium">Inference Speed</div>
              <div className="text-xs text-slate-600 mt-1">From 292ms to 250ms</div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  )
}
