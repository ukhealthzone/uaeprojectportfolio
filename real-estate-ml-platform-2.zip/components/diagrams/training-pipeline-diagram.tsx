import { Card } from "@/components/ui/card"
import { Database, Cpu, Brain, TrendingUp, CheckCircle2, GitBranch } from "lucide-react"

export function TrainingPipelineDiagram() {
  return (
    <Card className="p-8 bg-white">
      <div className="space-y-8">
        {/* Data Preparation */}
        <div>
          <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">1. Data Preparation</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="p-4 bg-blue-50 rounded-lg text-center">
              <Database className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <h4 className="font-semibold text-slate-900 text-sm mb-1">Load Data</h4>
              <p className="text-xs text-slate-600">18.7M records</p>
            </div>
            <div className="p-4 bg-purple-50 rounded-lg text-center">
              <GitBranch className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <h4 className="font-semibold text-slate-900 text-sm mb-1">Feature Eng.</h4>
              <p className="text-xs text-slate-600">247 features</p>
            </div>
            <div className="p-4 bg-amber-50 rounded-lg text-center">
              <TrendingUp className="w-8 h-8 text-amber-600 mx-auto mb-2" />
              <h4 className="font-semibold text-slate-900 text-sm mb-1">Normalize</h4>
              <p className="text-xs text-slate-600">StandardScaler</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg text-center">
              <CheckCircle2 className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <h4 className="font-semibold text-slate-900 text-sm mb-1">Split Data</h4>
              <p className="text-xs text-slate-600">70/15/15</p>
            </div>
          </div>
        </div>

        {/* Arrow Down */}
        <div className="flex justify-center">
          <div className="w-0.5 h-12 bg-slate-300 relative">
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0 border-t-8 border-t-slate-300 border-l-4 border-l-transparent border-r-4 border-r-transparent"></div>
          </div>
        </div>

        {/* Training */}
        <div>
          <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">2. Model Training (Parallel)</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="p-4 bg-slate-50 rounded-lg border-2 border-teal-200">
              <Brain className="w-6 h-6 text-teal-600 mb-2" />
              <h4 className="font-semibold text-slate-900 text-sm">XGBoost</h4>
              <p className="text-xs text-slate-600 mt-1">850 trees, depth=8</p>
              <div className="mt-2 text-xs font-medium text-teal-600">Weight: 30%</div>
            </div>
            <div className="p-4 bg-slate-50 rounded-lg border-2 border-teal-200">
              <Brain className="w-6 h-6 text-teal-600 mb-2" />
              <h4 className="font-semibold text-slate-900 text-sm">LightGBM</h4>
              <p className="text-xs text-slate-600 mt-1">1200 trees, fast</p>
              <div className="mt-2 text-xs font-medium text-teal-600">Weight: 25%</div>
            </div>
            <div className="p-4 bg-slate-50 rounded-lg border-2 border-teal-200">
              <Brain className="w-6 h-6 text-teal-600 mb-2" />
              <h4 className="font-semibold text-slate-900 text-sm">Random Forest</h4>
              <p className="text-xs text-slate-600 mt-1">500 trees</p>
              <div className="mt-2 text-xs font-medium text-teal-600">Weight: 15%</div>
            </div>
            <div className="p-4 bg-slate-50 rounded-lg border-2 border-purple-200">
              <Brain className="w-6 h-6 text-purple-600 mb-2" />
              <h4 className="font-semibold text-slate-900 text-sm">Neural Net</h4>
              <p className="text-xs text-slate-600 mt-1">5 layers, 256 units</p>
              <div className="mt-2 text-xs font-medium text-purple-600">Weight: 15%</div>
            </div>
            <div className="p-4 bg-slate-50 rounded-lg border-2 border-purple-200">
              <Brain className="w-6 h-6 text-purple-600 mb-2" />
              <h4 className="font-semibold text-slate-900 text-sm">LSTM</h4>
              <p className="text-xs text-slate-600 mt-1">Time series, 128 units</p>
              <div className="mt-2 text-xs font-medium text-purple-600">Weight: 10%</div>
            </div>
            <div className="p-4 bg-slate-50 rounded-lg border-2 border-blue-200">
              <Brain className="w-6 h-6 text-blue-600 mb-2" />
              <h4 className="font-semibold text-slate-900 text-sm">Ridge</h4>
              <p className="text-xs text-slate-600 mt-1">Linear baseline</p>
              <div className="mt-2 text-xs font-medium text-blue-600">Weight: 5%</div>
            </div>
          </div>
          <div className="mt-4 p-4 bg-slate-50 rounded-lg border border-slate-200">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-700">Training Infrastructure:</span>
              <span className="font-semibold text-slate-900">8x NVIDIA A100 GPUs • 48 hours full retrain</span>
            </div>
          </div>
        </div>

        {/* Arrow Down */}
        <div className="flex justify-center">
          <div className="w-0.5 h-12 bg-slate-300 relative">
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0 border-t-8 border-t-slate-300 border-l-4 border-l-transparent border-r-4 border-r-transparent"></div>
          </div>
        </div>

        {/* Validation */}
        <div>
          <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">3. Validation & Evaluation</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="p-4 bg-teal-50 rounded-lg border border-teal-200 text-center">
              <div className="text-2xl font-bold text-teal-600 mb-1">3.2%</div>
              <div className="text-xs text-slate-600">MAPE</div>
            </div>
            <div className="p-4 bg-teal-50 rounded-lg border border-teal-200 text-center">
              <div className="text-2xl font-bold text-teal-600 mb-1">0.94</div>
              <div className="text-xs text-slate-600">R² Score</div>
            </div>
            <div className="p-4 bg-teal-50 rounded-lg border border-teal-200 text-center">
              <div className="text-2xl font-bold text-teal-600 mb-1">87.3%</div>
              <div className="text-xs text-slate-600">ROI Accuracy</div>
            </div>
            <div className="p-4 bg-teal-50 rounded-lg border border-teal-200 text-center">
              <div className="text-2xl font-bold text-teal-600 mb-1">250ms</div>
              <div className="text-xs text-slate-600">Inference Time</div>
            </div>
          </div>
        </div>

        {/* Arrow Down */}
        <div className="flex justify-center">
          <div className="w-0.5 h-12 bg-slate-300 relative">
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0 border-t-8 border-t-slate-300 border-l-4 border-l-transparent border-r-4 border-r-transparent"></div>
          </div>
        </div>

        {/* Ensemble */}
        <div>
          <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">4. Ensemble & Deployment</h3>
          <div className="flex justify-center">
            <div className="p-6 bg-gradient-to-r from-teal-50 to-teal-100 rounded-lg border-2 border-teal-300 max-w-md">
              <div className="flex items-center gap-3 mb-4">
                <Cpu className="w-8 h-8 text-teal-600" />
                <div>
                  <h4 className="font-semibold text-slate-900">Weighted Ensemble</h4>
                  <p className="text-sm text-slate-600">Stacked generalization</p>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-700">Model Format:</span>
                  <span className="font-semibold text-slate-900">ONNX</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-700">Optimization:</span>
                  <span className="font-semibold text-slate-900">TensorRT</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-700">Deployment:</span>
                  <span className="font-semibold text-slate-900">Kubernetes</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Training Schedule */}
        <div className="pt-6 border-t border-slate-200">
          <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">Continuous Training Schedule</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-green-50 rounded-lg">
              <h4 className="font-semibold text-slate-900 text-sm mb-2">Daily (Incremental)</h4>
              <ul className="text-xs text-slate-600 space-y-1">
                <li>• Warm-start from previous weights</li>
                <li>• New data only (~100K records)</li>
                <li>• Duration: 4 hours</li>
              </ul>
            </div>
            <div className="p-4 bg-amber-50 rounded-lg">
              <h4 className="font-semibold text-slate-900 text-sm mb-2">Weekly (Quick Tune)</h4>
              <ul className="text-xs text-slate-600 space-y-1">
                <li>• Top 10 hyperparameters</li>
                <li>• 50 optimization trials</li>
                <li>• Duration: 6 hours</li>
              </ul>
            </div>
            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="font-semibold text-slate-900 text-sm mb-2">Monthly (Full Retrain)</h4>
              <ul className="text-xs text-slate-600 space-y-1">
                <li>• Complete retraining from scratch</li>
                <li>• Full hyperparameter sweep</li>
                <li>• Duration: 48 hours</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </Card>
  )
}
