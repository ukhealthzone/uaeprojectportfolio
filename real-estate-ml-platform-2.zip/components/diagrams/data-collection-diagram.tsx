import { Card } from "@/components/ui/card"
import { Globe, Database, FileText, Cloud, Server, CheckCircle2 } from "lucide-react"

export function DataCollectionDiagram() {
  return (
    <Card className="p-8 bg-white">
      <div className="space-y-8">
        {/* Source Layer */}
        <div>
          <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">Data Sources</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex flex-col items-center p-4 bg-blue-50 rounded-lg">
              <Globe className="w-8 h-8 text-blue-600 mb-2" />
              <span className="text-sm font-medium text-slate-900">Property Portals</span>
              <span className="text-xs text-slate-600">6 APIs</span>
            </div>
            <div className="flex flex-col items-center p-4 bg-green-50 rounded-lg">
              <FileText className="w-8 h-8 text-green-600 mb-2" />
              <span className="text-sm font-medium text-slate-900">Govt Records</span>
              <span className="text-xs text-slate-600">3 APIs</span>
            </div>
            <div className="flex flex-col items-center p-4 bg-purple-50 rounded-lg">
              <Cloud className="w-8 h-8 text-purple-600 mb-2" />
              <span className="text-sm font-medium text-slate-900">Web Scrapers</span>
              <span className="text-xs text-slate-600">350 crawlers</span>
            </div>
            <div className="flex flex-col items-center p-4 bg-amber-50 rounded-lg">
              <Server className="w-8 h-8 text-amber-600 mb-2" />
              <span className="text-sm font-medium text-slate-900">External APIs</span>
              <span className="text-xs text-slate-600">3 integrations</span>
            </div>
          </div>
        </div>

        {/* Arrow Down */}
        <div className="flex justify-center">
          <div className="w-0.5 h-12 bg-slate-300 relative">
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0 border-t-8 border-t-slate-300 border-l-4 border-l-transparent border-r-4 border-r-transparent"></div>
          </div>
        </div>

        {/* Collection Layer */}
        <div>
          <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">Data Collection Layer</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
              <h4 className="font-semibold text-slate-900 mb-2">API Ingestion</h4>
              <ul className="text-xs text-slate-600 space-y-1">
                <li>• REST API polling (15min)</li>
                <li>• Rate limiting & retries</li>
                <li>• Authentication handling</li>
              </ul>
            </div>
            <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
              <h4 className="font-semibold text-slate-900 mb-2">Web Scraping</h4>
              <ul className="text-xs text-slate-600 space-y-1">
                <li>• Selenium + BeautifulSoup</li>
                <li>• Proxy rotation</li>
                <li>• Anti-bot detection</li>
              </ul>
            </div>
            <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
              <h4 className="font-semibold text-slate-900 mb-2">Validation</h4>
              <ul className="text-xs text-slate-600 space-y-1">
                <li>• Schema validation</li>
                <li>• Data quality checks</li>
                <li>• Duplicate detection</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Arrow Down */}
        <div className="flex justify-center">
          <div className="w-0.5 h-12 bg-slate-300 relative">
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0 border-t-8 border-t-slate-300 border-l-4 border-l-transparent border-r-4 border-r-transparent"></div>
          </div>
        </div>

        {/* Storage Layer */}
        <div>
          <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">Raw Data Storage</h3>
          <div className="flex justify-center">
            <div className="p-6 bg-teal-50 rounded-lg border-2 border-teal-200 max-w-md">
              <div className="flex items-center gap-3 mb-3">
                <Database className="w-8 h-8 text-teal-600" />
                <div>
                  <h4 className="font-semibold text-slate-900">Delta Lake</h4>
                  <p className="text-sm text-slate-600">480GB • Partitioned by date & source</p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle2 className="w-4 h-4 text-teal-600" />
                <span className="text-slate-700">2.4M+ records ingested daily</span>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Footer */}
        <div className="pt-6 border-t border-slate-200">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-teal-600">99.2%</div>
              <div className="text-xs text-slate-600">Collection Uptime</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-teal-600">18.7M</div>
              <div className="text-xs text-slate-600">Total Records</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-teal-600">15min</div>
              <div className="text-xs text-slate-600">Update Frequency</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-teal-600">97.8%</div>
              <div className="text-xs text-slate-600">Data Quality Score</div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  )
}
