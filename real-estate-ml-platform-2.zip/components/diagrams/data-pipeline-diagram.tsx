import { Card } from "@/components/ui/card"
import { Database, Cpu, Brain } from "lucide-react"

export function DataPipelineDiagram() {
  return (
    <Card className="p-6 bg-white">
      <div className="flex flex-col md:flex-row items-center justify-around gap-8">
        <div className="flex flex-col items-center">
          <div className="w-16 h-16 bg-blue-100 rounded-xl flex items-center justify-center mb-3">
            <Database className="w-8 h-8 text-blue-600" />
          </div>
          <h3 className="font-bold text-slate-900">Raw Data</h3>
          <p className="text-sm text-slate-600">18.7M records</p>
        </div>

        <div className="w-full md:w-24 h-0.5 md:h-full md:w-0.5 bg-slate-300 relative hidden md:block">
          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-0 h-0 border-l-8 border-l-slate-300 border-t-4 border-t-transparent border-b-4 border-b-transparent"></div>
        </div>

        <div className="flex flex-col items-center">
          <div className="w-16 h-16 bg-purple-100 rounded-xl flex items-center justify-center mb-3">
            <Cpu className="w-8 h-8 text-purple-600" />
          </div>
          <h3 className="font-bold text-slate-900">Processing</h3>
          <p className="text-sm text-slate-600">Feature extraction</p>
        </div>

        <div className="w-full md:w-24 h-0.5 md:h-full md:w-0.5 bg-slate-300 relative hidden md:block">
          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-0 h-0 border-l-8 border-l-slate-300 border-t-4 border-t-transparent border-b-4 border-b-transparent"></div>
        </div>

        <div className="flex flex-col items-center">
          <div className="w-16 h-16 bg-teal-100 rounded-xl flex items-center justify-center mb-3">
            <Brain className="w-8 h-8 text-teal-600" />
          </div>
          <h3 className="font-bold text-slate-900">ML Models</h3>
          <p className="text-sm text-slate-600">Predictions</p>
        </div>
      </div>
    </Card>
  )
}
