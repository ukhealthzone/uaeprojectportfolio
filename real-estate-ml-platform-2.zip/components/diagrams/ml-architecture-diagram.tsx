import { Card } from "@/components/ui/card"
import { Database, Cpu, Brain, Zap, Activity } from "lucide-react"

export function MLArchitectureDiagram() {
  return (
    <Card className="p-8 bg-white">
      <div className="space-y-8">
        {/* Row 1 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 bg-blue-100 rounded-xl flex items-center justify-center mb-3">
              <Database className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="font-bold text-slate-900 mb-1">Data Sources</h3>
            <p className="text-sm text-slate-600 text-center">12 APIs • 350 scrapers</p>
          </div>

          <div className="flex items-center justify-center">
            <div className="w-full h-0.5 bg-slate-300 relative hidden md:block">
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-0 h-0 border-l-8 border-l-slate-300 border-t-4 border-t-transparent border-b-4 border-b-transparent"></div>
            </div>
          </div>

          <div className="flex flex-col items-center">
            <div className="w-16 h-16 bg-teal-100 rounded-xl flex items-center justify-center mb-3">
              <Database className="w-8 h-8 text-teal-600" />
            </div>
            <h3 className="font-bold text-slate-900 mb-1">Data Lake</h3>
            <p className="text-sm text-slate-600 text-center">480GB • Delta format</p>
          </div>
        </div>

        <div className="flex justify-center">
          <div className="w-0.5 h-12 bg-slate-300 relative">
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0 border-t-8 border-t-slate-300 border-l-4 border-l-transparent border-r-4 border-r-transparent"></div>
          </div>
        </div>

        {/* Row 2 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 bg-purple-100 rounded-xl flex items-center justify-center mb-3">
              <Cpu className="w-8 h-8 text-purple-600" />
            </div>
            <h3 className="font-bold text-slate-900 mb-1">ETL Pipeline</h3>
            <p className="text-sm text-slate-600 text-center">24/7 • 15min batches</p>
          </div>

          <div className="flex items-center justify-center">
            <div className="w-full h-0.5 bg-slate-300 relative hidden md:block">
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-0 h-0 border-l-8 border-l-slate-300 border-t-4 border-t-transparent border-b-4 border-b-transparent"></div>
            </div>
          </div>

          <div className="flex flex-col items-center">
            <div className="w-16 h-16 bg-amber-100 rounded-xl flex items-center justify-center mb-3">
              <Brain className="w-8 h-8 text-amber-600" />
            </div>
            <h3 className="font-bold text-slate-900 mb-1">ML Models</h3>
            <p className="text-sm text-slate-600 text-center">8 ensemble models</p>
          </div>
        </div>

        <div className="flex justify-center">
          <div className="w-0.5 h-12 bg-slate-300 relative">
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0 border-t-8 border-t-slate-300 border-l-4 border-l-transparent border-r-4 border-r-transparent"></div>
          </div>
        </div>

        {/* Row 3 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 bg-green-100 rounded-xl flex items-center justify-center mb-3">
              <Zap className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="font-bold text-slate-900 mb-1">Inference API</h3>
            <p className="text-sm text-slate-600 text-center">FastAPI • Redis cache</p>
          </div>

          <div className="flex items-center justify-center">
            <div className="w-full h-0.5 bg-slate-300 relative hidden md:block">
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-0 h-0 border-l-8 border-l-slate-300 border-t-4 border-t-transparent border-b-4 border-b-transparent"></div>
            </div>
          </div>

          <div className="flex flex-col items-center">
            <div className="w-16 h-16 bg-rose-100 rounded-xl flex items-center justify-center mb-3">
              <Activity className="w-8 h-8 text-rose-600" />
            </div>
            <h3 className="font-bold text-slate-900 mb-1">Frontend</h3>
            <p className="text-sm text-slate-600 text-center">React • Edge CDN</p>
          </div>
        </div>
      </div>
    </Card>
  )
}
